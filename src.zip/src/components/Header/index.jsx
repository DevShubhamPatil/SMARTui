import './index.css'
import UBSLogo from '../Images/ubsLogo.svg'

const Header = () => {
    return(
        <div className="appHeader">
            <div className="ubsLogo">{UBSLogo}</div>
            <div className="appName">SMART</div>
            <div className="appFullName">SWIFT Management & Automated Regulatory Tool</div>
        </div>
    )
}

export default Header